#ifndef	DEFAULTS_H
#define	DEFAULTS_H

#define    P_MOSI              B,2 // pin 51
#define    P_MISO              B,3 // pin 50
#define    P_SCK               B,1 // pin 52
#define    MCP2515_CS          B,0 // pin 53
#define    MCP2515_INT         E,4 // pin 2
#define    LED2_HIGH           H,5 // pin 8
#define    LED2_LOW            H,5 // pin 8

#endif	// DEFAULTS_H
